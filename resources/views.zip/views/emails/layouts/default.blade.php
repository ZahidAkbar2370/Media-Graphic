<div style="margin:0;background:#f8f8f8;color:#1f1f1f;font-family:Arial;font-size:14px;font-weight:400;line-height:1.7;margin:0;padding:0;text-align:left;width:100%!important;margin:0!important;padding:0!important;height:100%!important">
    <table style="border-spacing:0!important;border-collapse:collapse!important;table-layout:fixed!important;margin:0 auto!important;margin:0;background:#f8f8f8;border-collapse:collapse;border-spacing:0;color:#1f1f1f;font-family:Arial;font-size:14px;font-weight:400;height:100%;line-height:1.7;margin:0;padding:0;text-align:left;vertical-align:top;width:100%">

        <tbody>

            <tr style="padding:0;text-align:left;vertical-align:top">

                <td align="center" valign="top" style="margin:0;border-collapse:collapse;color:#1f1f1f;font-family:Arial;font-size:14px;font-weight:400;line-height:1.7;margin:0;padding:0;text-align:left;vertical-align:top;word-wrap:break-word">

                    <center style="min-width:600px;width:100%">

                        <table align="center" style="border-spacing:0!important;border-collapse:collapse!important;table-layout:fixed!important;margin:0 auto!important;margin:0 auto;background:#f8f8f8;border-collapse:collapse;border-spacing:0;float:none;margin:0 auto;padding:0;text-align:center;vertical-align:top;width:600px">

                                <tbody>
                                    <tr style="padding:0;text-align:left;vertical-align:top">
                                        <td style="margin:0;border-collapse:collapse;color:#1f1f1f;font-family:Arial;font-size:14px;font-weight:400;line-height:1.7;margin:0;padding:0;text-align:left;vertical-align:top;word-wrap:break-word">

                                            <table style="border-spacing:0!important;border-collapse:collapse!important;table-layout:fixed!important;margin:0 auto!important;border-collapse:collapse;border-spacing:0;display:table;padding:0;text-align:left;vertical-align:top;width:100%">
                                                    <tbody>
                                                        <tr style="padding:0;text-align:left;vertical-align:top">

                                                            <th style="margin:0 auto;color:#1f1f1f;font-family:Arial;font-size:14px;font-weight:400;line-height:1.7;margin:0 auto;padding:0;padding-bottom:12px;padding-left:0;padding-right:0;text-align:left;width:600px">

                                                                    <table style="border-spacing:0!important;border-collapse:collapse!important;table-layout:fixed!important;margin:0 auto!important;border-collapse:collapse;border-spacing:0;padding:0;text-align:left;vertical-align:top;width:100%">
                                                                        <tbody>
                                                                            <tr style="padding:0;text-align:left;vertical-align:top">
                                                                                <th style="margin:0;color:#1f1f1f;font-family:Arial;font-size:14px;font-weight:400;line-height:1.7;margin:0;padding:0;text-align:left">

                                                                                    @yield('content')
                                                                                </th>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                            </th>
                                                        </tr>
                                                    </tbody>
                                            </table>

                                        </td>
                                    </tr>
                                </tbody>

                        </table>

                    </center>

                </td>

            </tr>

        </tbody>
    </table>

</div>
