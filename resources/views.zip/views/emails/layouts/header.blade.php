<center style="min-width:524px;width:100%">
    <table cellspacing="0" cellpadding="0" border="0" align="center" width="600">
        <tbody>
            <tr>
                <td>
                    <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                            <tbody>
                                <tr>
                                    <td width="100%">
                                        <a href="{{ url('/') }}" target="_blank" > 
                                            <img src="{{ asset('assets/images/websiteimg/emails/header.png') }}" alt="" style="clear:both;display:block;max-width:100%;outline:0;text-decoration:none;width:100%" align="left" class="CToWUd">
                                        </a>
                                    </td>
                                </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
        </tbody>
    </table>
</center>