<footer>
    <div class="widget">
        <ul>
            <li><a href="protection-vie-privee.html">Protection des données personnelles</a></li>
            <li><a href="mentions-legales.html">Mentions légales</a></li>
            <li><a href="condition-de-vente.html">Conditions de vente</a></li>
        </ul>
    </div>
    <div class="widget">
        <ul>
            <li><a href="labellise.html">Labellisé "imprim'Vert"</a></li>
            <li><a href="#!">F.A.Q</a></li>
            <li><a href="nous-contacter.html">Nous contacter</a></li>
        </ul>
    </div>
    <div class="widget paiement">
        <h4>Moyens de paiement</h4>
        <img src="images/paiement.png">
    </div>
    <div class="copyright">
        <p>MAST Site <i class="far fa-copyright"></i> 2021 Tout les droits sont réservés</p>
    </div>
</footer>
@yield('footer_scripts')


