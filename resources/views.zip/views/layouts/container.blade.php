<main>
    @yield('content')
</main>
