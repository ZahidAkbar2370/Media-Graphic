<section class="services">
    <div>
        <h2><a href="{{ url('command_plan') }}">PLAN</a></h2>
    </div>
    <div>
        <h2><a href="{{ url('memory') }}">MÉMOIRE & RAPPORT</a></h2>
    </div>
    <div>
        <h2><a href="{{ url('booklet') }}">BROCHURE & LIVRET</a></h2>
    </div>
    <div>
        <h2><a href="{{ url('attach') }}">AFFICHE</a></h2>
    </div>
    <div>
        <h2><a href="{{ url('plans_life') }}">DOSSIER DE PLANS</a></h2>
    </div>
</section>
