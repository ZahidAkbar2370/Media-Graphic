<script src="{{ url('admin_assets/plugins/pace/pace.min.js') }}" type="text/javascript"></script>

    <!-- BEGIN JS DEPENDECENCIES-->

    <script src="{{ url('admin_assets/plugins/jquery/jquery-1.11.3.min.js') }}" type="text/javascript"></script>

    <script src="{{ url('admin_assets/plugins/bootstrapv3/js/bootstrap.min.js') }}" type="text/javascript"></script>

    <script src="{{ url('admin_assets/plugins/jquery-block-ui/jqueryblockui.min.js') }}" type="text/javascript"></script>

    <script src="{{ url('admin_assets/plugins/jquery-unveil/jquery.unveil.min.js') }}" type="text/javascript"></script>

    <script src="{{ url('admin_assets/plugins/jquery-scrollbar/jquery.scrollbar.min.js') }}" type="text/javascript">

    </script>

    <script src="{{ url('admin_assets/plugins/jquery-numberAnimate/jquery.animateNumbers.js') }}" type="text/javascript">

    </script>

    <script src="{{ url('admin_assets/plugins/jquery-validation/js/jquery.validate.min.js') }}" type="text/javascript">

    </script>

    <script src="{{ url('admin_assets/plugins/bootstrap-select2/select2.min.js') }}" type="text/javascript"></script>

    <!-- END CORE JS DEPENDECENCIES-->

    <!-- BEGIN CORE TEMPLATE JS -->

    <script src="webarch/js/webarch.js" type="text/javascript"></script>

    <script src="assets/js/chat.js" type="text/javascript"></script>

    <!-- END CORE TEMPLATE JS -->

    <!-- BEGIN PAGE LEVEL JS -->

    <script src="{{ url('admin_assets/plugins/jquery-ui/jquery-ui-1.10.1.custom.min.js') }}" type="text/javascript">

    </script>

    <script src="{{ url('admin_assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js') }}"

        type="text/javascript"></script>

    <script src="{{ url('admin_assets/plugins/jquery-block-ui/jqueryblockui.js') }}" type="text/javascript"></script>

    <script src="{{ url('admin_assets/plugins/bootstrap-select2/select2.min.js') }}" type="text/javascript"></script>

    <script src="{{ url('admin_assets/plugins/jquery-ricksaw-chart/js/raphael-min.js') }}"></script>

    <script src="{{ url('admin_assets/plugins/jquery-ricksaw-chart/js/d3.v2.js') }}"></script>

    <script src="{{ url('admin_assets/plugins/jquery-ricksaw-chart/js/rickshaw.min.js') }}"></script>

    <script src="{{ url('admin_assets/plugins/jquery-morris-chart/js/morris.min.js') }}"></script>

    <script src="{{ url('admin_assets/plugins/jquery-easy-pie-chart/js/jquery.easypiechart.min.js') }}"></script>

    <script src="{{ url('admin_assets/plugins/jquery-slider/jquery.sidr.min.js') }}" type="text/javascript"></script>

    <script src="{{ url('admin_assets/plugins/jquery-jvectormap/js/jquery-jvectormap-1.2.2.min.js') }}"

        type="text/javascript"></script>

    <script src="{{ url('admin_assets/plugins/jquery-jvectormap/js/jquery-jvectormap-us-lcc-en.js') }}"

        type="text/javascript"></script>

    <script src="{{ url('admin_assets/plugins/jquery-sparkline/jquery-sparkline.js') }}"></script>

    <script src="{{ url('admin_assets/plugins/jquery-flot/jquery.flot.min.js') }}"></script>

    <script src="{{ url('admin_assets/plugins/jquery-flot/jquery.flot.animator.min.js') }}"></script>

    <script src="{{ url('admin_assets/plugins/skycons/skycons.js') }}"></script>

    <!-- END PAGE LEVEL PLUGINS   -->

    <!-- PAGE JS -->

    <script src="assets/js/dashboard.js" type="text/javascript"></script>

    @yield('footer_scripts')