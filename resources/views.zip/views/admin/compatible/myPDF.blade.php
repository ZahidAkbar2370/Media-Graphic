<html>

<head>
    <title>Title of the document</title>
</head>

<body>
    <h1>Prescription From Doctors</h1>
    <iframe src="/uploads/media/default/0001/01/540cb75550adf33f281f29132dddd14fded85bfc.pdf#toolbar=0" width="100%"
        height="500px">
    </iframe>

    <table>
        <tr>
            <th>Name:</th>
            <th>Number</th>
            <th>Adress</th>
            <th>Age</th>
            <th>Cnic</th>
            <th>Gender</th>
            <th>Prescription</th>



        </tr>
        <tr>



            <td>{{ $get_payment->first_name }}</td>


        </tr>

    </table>



</body>

</html>
